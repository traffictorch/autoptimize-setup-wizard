<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class autoptimizeWizard {
    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_page' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );
        add_action( 'wp_ajax_ao_wizard_save', [ $this, 'handle_save' ] );
    }

    public function add_page() {
        add_submenu_page(
            'autoptimize',
            'Setup Wizard',
            'Setup Wizard',
            'manage_options',
            'ao-setup-wizard',
            [ $this, 'render' ]
        );
    }

    public function enqueue( $hook ) {
        if ( 'autoptimize_page_ao-setup-wizard' !== $hook ) return;
        wp_enqueue_style( 'ao-wizard-css', plugins_url( '/static/css/ao-wizard.css', __FILE__ ), [], '1.0' );
        wp_enqueue_script( 'ao-wizard-js', plugins_url( '/static/js/ao-wizard.js', __FILE__ ), [ 'jquery' ], '1.0', true );
        wp_localize_script( 'ao-wizard-js', 'aoWizard', [
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'ao_wizard_save' )
        ] );
    }

    public function render() {
        $config = autoptimizeConfig::instance();
        $settings = $config->get_all(); // Get current settings

        ?>
        <div class="wrap">
            <h1>Autoptimize Setup Wizard</h1>
            <div class="ao-wizard-container">
                <div class="ao-progress-bar"><div class="ao-progress-fill"></div></div>

                <form id="ao-wizard-form" method="post">
                    <input type="hidden" name="action" value="ao_wizard_save">
                    <?php wp_nonce_field( 'ao_wizard_save', '_ajax_nonce' ); ?>

                    <!-- Step 1: Welcome & Backup -->
                    <div class="ao-step active">
                        <h2>Welcome to Autoptimize Setup Wizard</h2>
                        <p>This guided wizard will safely optimize your site for maximum performance.</p>
                        <div class="ao-card">
                            <h3>Safety First: Backup Your Site</h3>
                            <p>Optimization can affect site rendering. Always back up first!</p>
                            <p>Recommended plugins: <a href="https://wordpress.org/plugins/updraftplus/">UpdraftPlus</a> or <a href="https://wordpress.org/plugins/backupbuddy/">BackupBuddy</a>.</p>
                            <label class="ao-checkbox">
                                <input type="checkbox" id="backup-confirm" required>
                                <span>I have backed up my site and am ready to proceed.</span>
                            </label>
                        </div>
                    </div>

                    <!-- Step 2: Detection & Recommendations -->
                    <div class="ao-step">
                        <h2>Smart Detection</h2>
                        <p>We scanned your setup. Here's our recommendation for max performance:</p>
                        <div class="ao-card">
                            <p><strong>Theme:</strong> <?php echo esc_html( wp_get_theme()->get( 'Name' ) ); ?></p>
                            <p><strong>Conflicts:</strong> None detected (or list if any).</p>
                            <p>Defaults: Enable HTML/JS/CSS optimization, defer JS, basic exclusions.</p>
                        </div>
                    </div>

                    <!-- Step 3: JavaScript -->
                    <div class="ao-step">
                        <h2>Optimize JavaScript</h2>
                        <div class="ao-card">
                            <label class="ao-checkbox">
                                <input type="checkbox" name="autoptimize_js" <?php checked( $settings['autoptimize_js'] ); ?>>
                                <span>Enable JS Optimization (aggregate, minify, defer)</span>
                            </label>
                            <p>Exclusions (comma-separated): <input type="text" name="autoptimize_js_exclude" value="<?php echo esc_attr( $settings['autoptimize_js_exclude'] ); ?>" style="width:100%;"></p>
                            <p>Tip: Defer JS improves load times—test key pages after.</p>
                        </div>
                    </div>

                    <!-- Step 4: CSS -->
                    <div class="ao-step">
                        <h2>Optimize CSS</h2>
                        <div class="ao-card">
                            <label class="ao-checkbox">
                                <input type="checkbox" name="autoptimize_css" <?php checked( $settings['autoptimize_css'] ); ?>>
                                <span>Enable CSS Optimization (aggregate, minify)</span>
                            </label>
                            <p>Inline small CSS: <input type="checkbox" name="autoptimize_css_inline" <?php checked( $settings['autoptimize_css_inline'] ); ?>></p>
                            <p>Exclusions: <input type="text" name="autoptimize_css_exclude" value="<?php echo esc_attr( $settings['autoptimize_css_exclude'] ); ?>" style="width:100%;"></p>
                        </div>
                    </div>

                    <!-- Step 5: HTML & Extras -->
                    <div class="ao-step">
                        <h2>HTML & Extras</h2>
                        <div class="ao-card">
                            <label class="ao-checkbox">
                                <input type="checkbox" name="autoptimize_html" <?php checked( $settings['autoptimize_html'] ); ?>>
                                <span>Optimize HTML</span>
                            </label>
                            <label class="ao-checkbox">
                                <input type="checkbox" name="autoptimize_remove_emojis" <?php checked( $settings['autoptimize_remove_emojis'] ); ?>>
                                <span>Remove Emojis</span>
                            </label>
                            <p>Other extras can be added in settings later.</p>
                        </div>
                    </div>

                    <!-- Step 6: Review -->
                    <div class="ao-step">
                        <h2>Review & Apply</h2>
                        <p>These settings will be applied. Click "Apply & Optimize" to save.</p>
                        <div class="ao-warning">
                            <strong>After applying:</strong> Clear cache, test your site thoroughly.
                        </div>
                    </div>

                    <div style="display: flex; justify-content: space-between; margin-top: 30px;">
                        <button type="button" class="ao-btn ao-prev" disabled>Previous</button>
                        <button type="button" class="ao-btn ao-next">Next</button>
                    </div>
                </form>
            </div>
        </div>
        <?php
    }

    public function handle_save() {
        check_ajax_referer( 'ao_wizard_save', '_ajax_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'No permission' );
        }

        $config = autoptimizeConfig::instance();
        $config->set( 'autoptimize_js', isset( $_POST['autoptimize_js'] ) );
        $config->set( 'autoptimize_js_exclude', sanitize_text_field( $_POST['autoptimize_js_exclude'] ?? '' ) );
        $config->set( 'autoptimize_css', isset( $_POST['autoptimize_css'] ) );
        $config->set( 'autoptimize_css_exclude', sanitize_text_field( $_POST['autoptimize_css_exclude'] ?? '' ) );
        $config->set( 'autoptimize_css_inline', isset( $_POST['autoptimize_css_inline'] ) );
        $config->set( 'autoptimize_html', isset( $_POST['autoptimize_html'] ) );
        $config->set( 'autoptimize_remove_emojis', isset( $_POST['autoptimize_remove_emojis'] ) );

        $config->update(); // Save all changes

        wp_send_json_success();
    }
}

new autoptimizeWizard();