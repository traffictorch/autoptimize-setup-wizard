jQuery(document).ready(function($) {
    const steps = $('.ao-step');
    const progressFill = $('.ao-progress-fill');
    const prevBtn = $('.ao-prev');
    const nextBtn = $('.ao-next');
    const form = $('#ao-wizard-form');
    let currentStep = 0;

    function showStep(index) {
        steps.removeClass('active').eq(index).addClass('active');
        progressFill.css('width', ((index + 1) / steps.length * 100) + '%');
        prevBtn.prop('disabled', index === 0);
        nextBtn.text(index === steps.length - 1 ? 'Apply & Optimize' : 'Next');
    }

    prevBtn.on('click', function() {
        if (currentStep > 0) {
            currentStep--;
            showStep(currentStep);
        }
    });

    nextBtn.on('click', function() {
        if (currentStep < steps.length - 1) {
            // Basic validation (backup checkbox)
            if (currentStep === 0 && !$('#backup-confirm').is(':checked')) {
                alert('Please confirm you have a backup before proceeding.');
                return;
            }
            currentStep++;
            showStep(currentStep);
        } else {
            // Final step: submit via AJAX
            const formData = form.serialize();
            $.post(ajaxurl, {
                action: 'ao_wizard_save',
                data: formData,
                _ajax_nonce: aoWizard.nonce
            }, function(response) {
                if (response.success) {
                    $('.ao-wizard-container').html(`
                        <div class="ao-cta">
                            <h2>Optimization Complete! Your site is faster.</h2>
                            <p>Unlock image optimization, critical CSS, CDN, and more with Autoptimize Pro.</p>
                            <a href="https://autoptimize.com/pro/" target="_blank">Upgrade to Pro Now</a>
                            <p>Thanks for using the wizard! ❤️</p>
                        </div>
                    `);
                } else {
                    alert('Error saving settings: ' + (response.data || 'Unknown error'));
                }
            });
        }
    });

    // Initial display
    showStep(0);
});