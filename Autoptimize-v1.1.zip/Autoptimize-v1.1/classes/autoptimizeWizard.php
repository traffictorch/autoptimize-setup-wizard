<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class autoptimizeWizard {
    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_page' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );
        add_action( 'wp_ajax_ao_wizard_save', [ $this, 'handle_save' ] );
    }

    public function add_page() {
        add_submenu_page(
            'autoptimize',
            'Setup Wizard',
            'Setup Wizard',
            'manage_options',
            'ao-setup-wizard',
            [ $this, 'render' ]
        );
    }

    public function enqueue( $hook ) {
        if ( 'autoptimize_page_ao-setup-wizard' !== $hook ) return;
        wp_enqueue_style( 'ao-wizard-css', plugins_url( '/static/css/ao-wizard.css', __FILE__ ), [], '1.0' );
        wp_enqueue_script( 'ao-wizard-js', plugins_url( '/static/js/ao-wizard.js', __FILE__ ), [ 'jquery' ], '1.0', true );
        wp_localize_script( 'ao-wizard-js', 'aoWizard', [
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'ao_wizard_save' )
        ] );
    }

    public function render() {
        $config = autoptimizeConfig::instance();
        $settings = $config->get_all();

        // Analysis data
        $theme = wp_get_theme();
        $theme_name = $theme->get('Name');
        $is_light_theme = in_array( strtolower( $theme_name ), [ 'astra', 'generatepress', 'hello elementor', 'kadence', 'oceanwp', 'neve', 'blocksy' ] );

        $has_page_builder = (
            is_plugin_active( 'elementor/elementor.php' ) ||
            is_plugin_active( 'beaver-builder-lite-version/fl-builder.php' ) ||
            is_plugin_active( 'siteorigin-panels/siteorigin-panels.php' ) ||
            is_plugin_active( 'js_composer/js_composer.php' ) || // WPBakery
            is_plugin_active( 'divi-builder/divi-builder.php' )
        );

        $has_woocommerce = class_exists( 'WooCommerce' );

        $conflicting_plugins = [];
        $potential_conflicts = [
            'wp-rocket/wp-rocket.php'          => 'WP Rocket',
            'litespeed-cache/litespeed-cache.php' => 'LiteSpeed Cache',
            'w3-total-cache/w3-total-cache.php'  => 'W3 Total Cache',
            'wp-fastest-cache/wpFastestCache.php' => 'WP Fastest Cache',
            'cache-enabler/cache-enabler.php'    => 'Cache Enabler',
            'flying-press/flying-press.php'      => 'FlyingPress',
        ];
        foreach ( $potential_conflicts as $plugin_file => $name ) {
            if ( is_plugin_active( $plugin_file ) ) {
                $conflicting_plugins[] = $name;
            }
        }

        // Recommendation logic
        $rec_js_aggregate = $is_light_theme && ! $has_page_builder;
        $rec_js_defer     = true; // almost always safe
        $rec_css_aggregate = $is_light_theme && ! $has_page_builder;
        $rec_css_inline    = $is_light_theme && ! $has_page_builder;
        $rec_html          = true;

        $suggested_js_exclusions  = $has_woocommerce ? 'woocommerce/assets/js/, wc-ajax=get_refreshed_fragments, jquery-migrate' : '';
        $suggested_css_exclusions = $has_woocommerce ? 'woocommerce/assets/css/woocommerce-layout.css, woocommerce-smallscreen.css' : '';

        $has_conflicts_warning = ! empty( $conflicting_plugins ) || $has_page_builder;

        ?>
        <div class="wrap">
            <h1>Autoptimize Setup Wizard</h1>
            <div class="ao-wizard-container">
                <div class="ao-progress-bar"><div class="ao-progress-fill"></div></div>

                <form id="ao-wizard-form" method="post">
                    <input type="hidden" name="action" value="ao_wizard_save">
                    <?php wp_nonce_field( 'ao_wizard_save', '_ajax_nonce' ); ?>

                    <!-- Step 1: Welcome & Backup -->
                    <div class="ao-step active">
                        <h2>Welcome to Autoptimize Setup Wizard</h2>
                        <p>This guided wizard analyzes your site and safely applies the best optimization settings.</p>
                        <div class="ao-card">
                            <h3>Safety First: Backup Your Site</h3>
                            <p>Optimization changes can affect how your site looks or functions. Always back up first!</p>
                            <p>Recommended free plugins: <a href="https://wordpress.org/plugins/updraftplus/" target="_blank">UpdraftPlus</a> or <a href="https://wordpress.org/plugins/backupbuddy/" target="_blank">BackupBuddy</a>.</p>
                            <label class="ao-checkbox">
                                <input type="checkbox" id="backup-confirm" required>
                                <span>I confirm I have backed up my site and understand testing is recommended after changes.</span>
                            </label>
                        </div>
                    </div>

                    <!-- Step 2: Analysis & Recommendations -->
                    <div class="ao-step">
                        <h2>Site Analysis & Recommended Settings</h2>
                        <p>We examined your current Autoptimize configuration, theme, plugins, and site type. Here are tailored recommendations:</p>

                        <?php if ( $has_conflicts_warning ): ?>
                            <div class="ao-warning">
                                <strong>Caution detected:</strong> 
                                <?php if ( $has_page_builder ) echo 'Page builder active — start conservative.'; ?>
                                <?php if ( ! empty( $conflicting_plugins ) ) echo ' Other optimization plugins found: ' . implode( ', ', $conflicting_plugins ) . ' → consider disabling overlapping features.'; ?>
                            </div>
                        <?php endif; ?>

                        <div class="ao-card">
                            <ul style="list-style:none; padding:0; margin:0 0 20px;">
                                <li><strong>Theme:</strong> <?php echo esc_html( $theme_name ); ?> 
                                    <?php echo $is_light_theme ? '(lightweight — aggressive optimization usually safe)' : '(heavier — more caution advised)'; ?></li>
                                <li><strong>Page Builder:</strong> <?php echo $has_page_builder ? 'Yes' : 'No'; ?></li>
                                <li><strong>WooCommerce:</strong> <?php echo $has_woocommerce ? 'Yes' : 'No'; ?></li>
                                <li><strong>Current AO:</strong> 
                                    <?php echo !empty($settings['autoptimize_js']) ? 'JS enabled' : 'JS disabled'; ?>, 
                                    <?php echo !empty($settings['autoptimize_css']) ? 'CSS enabled' : 'CSS disabled'; ?>, 
                                    <?php echo !empty($settings['autoptimize_html']) ? 'HTML enabled' : 'HTML disabled'; ?>
                                </li>
                            </ul>

                            <h3>Our Recommendations</h3>
                            <ul>
                                <li>JS Optimization: <strong><?php echo $rec_js_aggregate ? 'Enable + Aggregate + Defer' : 'Enable but keep files separate (safer)'; ?></strong></li>
                                <li>CSS Optimization: <strong><?php echo $rec_css_aggregate ? 'Enable + Aggregate + Inline small CSS' : 'Enable but keep separate'; ?></strong></li>
                                <li>HTML Optimization: <strong>Enable (almost always safe)</strong></li>
                                <?php if ( $suggested_js_exclusions ): ?>
                                    <li>JS Exclusions (suggested): <code><?php echo esc_html( $suggested_js_exclusions ); ?></code></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>

                    <!-- Step 3: JavaScript -->
                    <div class="ao-step">
                        <h2>Optimize JavaScript</h2>
                        <div class="ao-card">
                            <label class="ao-checkbox">
                                <input type="checkbox" name="autoptimize_js" <?php checked( $rec_js_aggregate || !empty($settings['autoptimize_js']) ); ?>>
                                <span>Enable JavaScript Optimization</span>
                            </label>
                            <p><small>Pre-checked based on analysis. Aggregate and defer are recommended for most sites unless you have a page builder.</small></p>

                            <label class="ao-checkbox" style="margin-top:15px;">
                                <input type="checkbox" name="autoptimize_js_aggregate" <?php checked( $rec_js_aggregate ); ?>>
                                <span>Aggregate JS into one file (reduces requests)</span>
                            </label>

                            <label class="ao-checkbox">
                                <input type="checkbox" name="autoptimize_js_defer" <?php checked( $rec_js_defer ); ?>>
                                <span>Defer JS (improves perceived load time)</span>
                            </label>

                            <p>Exclusions (comma-separated, pre-filled from analysis):<br>
                                <input type="text" name="autoptimize_js_exclude" value="<?php echo esc_attr( $suggested_js_exclusions ?: $settings['autoptimize_js_exclude'] ?? '' ); ?>" style="width:100%; padding:8px; margin-top:5px;">
                            </p>
                        </div>
                    </div>

                    <!-- Step 4: CSS -->
                    <div class="ao-step">
                        <h2>Optimize CSS</h2>
                        <div class="ao-card">
                            <label class="ao-checkbox">
                                <input type="checkbox" name="autoptimize_css" <?php checked( $rec_css_aggregate || !empty($settings['autoptimize_css']) ); ?>>
                                <span>Enable CSS Optimization</span>
                            </label>

                            <label class="ao-checkbox" style="margin-top:15px;">
                                <input type="checkbox" name="autoptimize_css_aggregate" <?php checked( $rec_css_aggregate ); ?>>
                                <span>Aggregate CSS into one file</span>
                            </label>

                            <label class="ao-checkbox">
                                <input type="checkbox" name="autoptimize_css_inline" <?php checked( $rec_css_inline ); ?>>
                                <span>Inline small CSS (reduces requests)</span>
                            </label>

                            <p>Exclusions (comma-separated):<br>
                                <input type="text" name="autoptimize_css_exclude" value="<?php echo esc_attr( $suggested_css_exclusions ?: $settings['autoptimize_css_exclude'] ?? '' ); ?>" style="width:100%; padding:8px; margin-top:5px;">
                            </p>
                        </div>
                    </div>

                    <!-- Step 5: HTML & Extras -->
                    <div class="ao-step">
                        <h2>HTML & Extras</h2>
                        <div class="ao-card">
                            <label class="ao-checkbox">
                                <input type="checkbox" name="autoptimize_html" <?php checked( $rec_html || !empty($settings['autoptimize_html']) ); ?>>
                                <span>Optimize HTML (minify, remove whitespace/comments)</span>
                            </label>

                            <label class="ao-checkbox" style="margin-top:15px;">
                                <input type="checkbox" name="autoptimize_remove_emojis" <?php checked( !empty($settings['autoptimize_remove_emojis']) ); ?>>
                                <span>Remove WordPress emojis</span>
                            </label>

                            <p><small>These are safe for nearly all sites and provide quick wins.</small></p>
                        </div>
                    </div>

                    <!-- Step 6: Review -->
                    <div class="ao-step">
                        <h2>Review & Apply Changes</h2>
                        <div class="ao-card">
                            <p>Review the settings above (pre-filled from analysis). When ready, click "Apply & Optimize" below.</p>
                            <div class="ao-warning">
                                <strong>After applying:</strong> Clear any site caches, test key pages (homepage, checkout if WooCommerce), and check for console errors.
                            </div>
                        </div>
                    </div>

                    <div style="display: flex; justify-content: space-between; margin-top: 30px;">
                        <button type="button" class="ao-btn ao-prev" disabled>Previous</button>
                        <button type="button" class="ao-btn ao-next">Next</button>
                    </div>
                </form>
            </div>
        </div>
        <?php
    }

    public function handle_save() {
        check_ajax_referer( 'ao_wizard_save', '_ajax_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'No permission' );
        }

        $config = autoptimizeConfig::instance();

        // Core toggles
        $config->set( 'autoptimize_js', isset( $_POST['autoptimize_js'] ) );
        $config->set( 'autoptimize_css', isset( $_POST['autoptimize_css'] ) );
        $config->set( 'autoptimize_html', isset( $_POST['autoptimize_html'] ) );

        // JS advanced
        $config->set( 'autoptimize_js_aggregate', isset( $_POST['autoptimize_js_aggregate'] ) );
        $config->set( 'autoptimize_js_defer', isset( $_POST['autoptimize_js_defer'] ) );
        $config->set( 'autoptimize_js_exclude', sanitize_text_field( $_POST['autoptimize_js_exclude'] ?? '' ) );

        // CSS advanced
        $config->set( 'autoptimize_css_aggregate', isset( $_POST['autoptimize_css_aggregate'] ) );
        $config->set( 'autoptimize_css_inline', isset( $_POST['autoptimize_css_inline'] ) );
        $config->set( 'autoptimize_css_exclude', sanitize_text_field( $_POST['autoptimize_css_exclude'] ?? '' ) );

        // Extras
        $config->set( 'autoptimize_remove_emojis', isset( $_POST['autoptimize_remove_emojis'] ) );

        $config->update();

        wp_send_json_success();
    }
}

new autoptimizeWizard();